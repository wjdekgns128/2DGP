import game_framework
import maptool


game_framework.run(maptool)
