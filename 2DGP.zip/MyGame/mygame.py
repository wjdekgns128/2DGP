import game_framework
import Logo.Logo


game_framework.run(Logo.Logo)
